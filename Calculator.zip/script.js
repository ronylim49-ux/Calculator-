(() => {
  'use strict';

  const HISTORY_KEY = 'northstar-calculator-history-v1';
  const SETTINGS_KEY = 'northstar-calculator-settings-v1';
  const DEFAULT_SETTINGS = { theme: 'dark', sound: false, precision: 8, buttonStyle: 'rounded', angle: 'deg', memory: 0 };
  const FUNCTIONS = new Set(['sin', 'cos', 'tan', 'log', 'ln', 'sqrt']);
  const OPERATORS = new Set(['+', '-', '*', '/', '^']);
  const MODES = {
    standard: { title: 'Standard calculator', kicker: 'EVERYDAY MATH', description: 'A simple space for the numbers that keep your day moving.', label: 'STANDARD' },
    scientific: { title: 'Scientific calculator', kicker: 'GO A LITTLE FURTHER', description: 'Explore functions, powers, and the constants behind the numbers.', label: 'SCIENTIFIC' },
    percentage: { title: 'Percentage calculator', kicker: 'MAKE SENSE OF THE MARGINS', description: 'Work out a percentage or see what a change looks like.', label: 'PERCENTAGE' },
    history: { title: 'Calculation history', kicker: 'PICK UP WHERE YOU LEFT OFF', description: 'Your calculations, ready when you need them.', label: 'HISTORY' }
  };

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const safeLoad = (key, fallback) => {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch {
      return fallback;
    }
  };
  const safeSave = (key, value) => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { showToast('Storage is unavailable in this browser.'); }
  };

  const loadedSettings = safeLoad(SETTINGS_KEY, {});
  const state = {
    mode: 'standard',
    expression: '',
    justEvaluated: false,
    lastResult: 0,
    lastFormula: '',
    error: '',
    history: Array.isArray(safeLoad(HISTORY_KEY, [])) ? safeLoad(HISTORY_KEY, []).slice(0, 100) : [],
    settings: { ...DEFAULT_SETTINGS, ...(loadedSettings && typeof loadedSettings === 'object' ? loadedSettings : {}) },
    percentOperation: 'of',
    percentResult: 36,
    toastTimer: null,
    audioContext: null
  };
  if (!['dark', 'light'].includes(state.settings.theme)) state.settings.theme = 'dark';
  if (!['rounded', 'square'].includes(state.settings.buttonStyle)) state.settings.buttonStyle = 'rounded';
  if (![2, 4, 6, 8, 10, 12].includes(Number(state.settings.precision))) state.settings.precision = 8;
  state.settings.precision = Number(state.settings.precision);
  if (!['deg', 'rad'].includes(state.settings.angle)) state.settings.angle = 'deg';
  state.settings.sound = Boolean(state.settings.sound);
  state.settings.memory = Number.isFinite(Number(state.settings.memory)) ? Number(state.settings.memory) : 0;

  const expressionDisplay = $('#expression-display');
  const resultDisplay = $('#result-display');
  const displayMessage = $('#display-message');
  const modeTitle = $('#mode-title');
  const modeKicker = $('#mode-kicker');
  const modeDescription = $('#mode-description');
  const calculatorPanel = $('#calculator-panel');
  const percentagePanel = $('#percentage-panel');
  const historyPanel = $('#history-panel');
  const scientificKeys = $('#scientific-keys');
  const keypad = $('#keypad');
  const toast = $('#toast');
  const settingsDialog = $('#settings-dialog');

  function persistSettings() { safeSave(SETTINGS_KEY, state.settings); }

  function formatNumber(value) {
    if (!Number.isFinite(value)) return 'Error';
    if (Object.is(value, -0) || Math.abs(value) < Number.EPSILON) value = 0;
    const precision = state.settings.precision;
    if (Math.abs(value) >= 1e16) {
      return value.toExponential(Math.min(precision, 8)).replace(/(?:\.0+|(?:(\.\d*?)0+))e/, '$1e').replace('e+', 'e');
    }
    const fixed = value.toFixed(precision);
    return fixed.replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1');
  }

  function cleanNumber(value) {
    if (!Number.isFinite(value)) return String(value);
    if (Object.is(value, -0)) return '0';
    return String(Number(value.toPrecision(15)));
  }

  function displayExpression(expression) {
    return expression
      .replace(/\*/g, '×').replace(/\//g, '÷').replace(/-/g, '−')
      .replace(/\bpi\b/gi, 'π').replace(/\b(E)\b/g, 'e');
  }

  function tokenize(source) {
    const tokens = [];
    let index = 0;
    while (index < source.length) {
      const rest = source.slice(index);
      if (/^\s/.test(rest)) { index += 1; continue; }
      const number = rest.match(/^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/);
      if (number) {
        tokens.push({ type: 'number', value: Number(number[0]) });
        index += number[0].length;
        continue;
      }
      const identifier = rest.match(/^[a-zA-Z]+|^π/);
      if (identifier) {
        const raw = identifier[0];
        const name = raw === 'π' ? 'pi' : raw.toLowerCase();
        if (name === 'pi' || name === 'e') tokens.push({ type: 'constant', value: name });
        else if (FUNCTIONS.has(name)) tokens.push({ type: 'function', value: name });
        else throw new Error(`“${raw}” is not a supported function or constant.`);
        index += raw.length;
        continue;
      }
      let symbol = source[index];
      if (symbol === '×') symbol = '*';
      if (symbol === '÷') symbol = '/';
      if (symbol === '−') symbol = '-';
      if (OPERATORS.has(symbol)) tokens.push({ type: 'operator', value: symbol });
      else if (symbol === '(') tokens.push({ type: 'leftParen', value: symbol });
      else if (symbol === ')') tokens.push({ type: 'rightParen', value: symbol });
      else if (symbol === '!') tokens.push({ type: 'factorial', value: symbol });
      else if (symbol === '%') tokens.push({ type: 'percent', value: symbol });
      else throw new Error(`The character “${source[index]}” cannot be calculated.`);
      index += 1;
    }

    const expanded = [];
    const endsValue = token => ['number', 'constant', 'rightParen', 'factorial', 'percent'].includes(token.type);
    const startsValue = token => ['number', 'constant', 'leftParen', 'function'].includes(token.type);
    for (const token of tokens) {
      const previous = expanded[expanded.length - 1];
      if (previous && endsValue(previous) && startsValue(token)) expanded.push({ type: 'operator', value: '*' });
      expanded.push(token);
    }
    return expanded;
  }

  function evaluate(source) {
    const tokens = tokenize(source);
    if (!tokens.length) throw new Error('Enter a calculation first.');
    let cursor = 0;
    const peek = () => tokens[cursor];
    const take = () => tokens[cursor++];
    const expect = (type, message) => {
      if (!peek() || peek().type !== type) throw new Error(message);
      return take();
    };
    const checked = (value, message = 'That result is outside the calculator’s range.') => {
      if (!Number.isFinite(value)) throw new Error(message);
      return { value, percent: false };
    };

    function parseAdd() {
      let left = parseMultiply();
      while (peek() && peek().type === 'operator' && ['+', '-'].includes(peek().value)) {
        const operator = take().value;
        const right = parseMultiply();
        let rightValue = right.value;
        if (right.percent && !left.percent) rightValue = left.value * right.value;
        const next = operator === '+' ? left.value + rightValue : left.value - rightValue;
        left = checked(next);
      }
      return left;
    }

    function parseMultiply() {
      let left = parseUnary();
      while (peek() && peek().type === 'operator' && ['*', '/'].includes(peek().value)) {
        const operator = take().value;
        const right = parseUnary();
        if (operator === '/' && right.value === 0) throw new Error('Division by zero is undefined.');
        left = checked(operator === '*' ? left.value * right.value : left.value / right.value);
      }
      return left;
    }

    function parseUnary() {
      if (peek() && peek().type === 'operator' && ['+', '-'].includes(peek().value)) {
        const sign = take().value === '-' ? -1 : 1;
        const value = parseUnary();
        return { value: sign * value.value, percent: value.percent };
      }
      return parsePower();
    }

    function parsePower() {
      const base = parsePostfix();
      if (peek() && peek().type === 'operator' && peek().value === '^') {
        take();
        const exponent = parseUnary();
        return checked(Math.pow(base.value, exponent.value), 'That power does not have a real, finite result.');
      }
      return base;
    }

    function parsePostfix() {
      let value = parsePrimary();
      while (peek() && ['factorial', 'percent'].includes(peek().type)) {
        const postfix = take().type;
        if (postfix === 'percent') value = { value: value.value / 100, percent: true };
        else {
          if (value.value < 0 || !Number.isInteger(value.value)) throw new Error('Factorial is defined here for whole numbers from 0 to 170.');
          if (value.value > 170) throw new Error('That factorial is too large to display.');
          let factorial = 1;
          for (let n = 2; n <= value.value; n += 1) factorial *= n;
          value = checked(factorial);
        }
      }
      return value;
    }

    function parsePrimary() {
      const token = peek();
      if (!token) throw new Error('Finish the expression with a number.');
      if (token.type === 'number') { take(); return checked(token.value); }
      if (token.type === 'constant') { take(); return checked(token.value === 'pi' ? Math.PI : Math.E); }
      if (token.type === 'leftParen') {
        take();
        const value = parseAdd();
        expect('rightParen', 'Add a closing parenthesis to finish the expression.');
        return value;
      }
      if (token.type === 'function') {
        const name = take().value;
        expect('leftParen', `Add an opening parenthesis after ${name}.`);
        const argument = parseAdd().value;
        expect('rightParen', 'Add a closing parenthesis to finish the function.');
        switch (name) {
          case 'sin': return checked(Math.sin(state.settings.angle === 'deg' ? argument * Math.PI / 180 : argument));
          case 'cos': return checked(Math.cos(state.settings.angle === 'deg' ? argument * Math.PI / 180 : argument));
          case 'tan': {
            const angle = state.settings.angle === 'deg' ? argument * Math.PI / 180 : argument;
            if (Math.abs(Math.cos(angle)) < 1e-12) throw new Error('Tangent is undefined at this angle.');
            return checked(Math.tan(angle));
          }
          case 'log':
            if (argument <= 0) throw new Error('Logarithm needs a value greater than zero.');
            return checked(Math.log10(argument));
          case 'ln':
            if (argument <= 0) throw new Error('Natural logarithm needs a value greater than zero.');
            return checked(Math.log(argument));
          case 'sqrt':
            if (argument < 0) throw new Error('Square root needs a value of zero or greater.');
            return checked(Math.sqrt(argument));
          default: throw new Error('That function is not available.');
        }
      }
      if (token.type === 'rightParen') throw new Error('There is a closing parenthesis without a matching opening one.');
      if (token.type === 'operator') throw new Error('Add a number before this operator.');
      throw new Error('This expression needs another number.');
    }

    const result = parseAdd();
    if (cursor < tokens.length) {
      if (peek().type === 'rightParen') throw new Error('There is a closing parenthesis without a matching opening one.');
      throw new Error('Check the operators in this expression.');
    }
    return result.value;
  }

  function previewValue() {
    if (!state.expression) return 0;
    return evaluate(state.expression);
  }

  function updateDisplay() {
    expressionDisplay.textContent = state.justEvaluated && state.lastFormula
      ? `${displayExpression(state.lastFormula)} =`
      : state.expression ? displayExpression(state.expression) : 'Enter a calculation';
    resultDisplay.textContent = state.expression ? '—' : '0';
    displayMessage.textContent = state.error;
    if (state.expression && !state.error) {
      try { resultDisplay.textContent = formatNumber(previewValue()); } catch { resultDisplay.textContent = '—'; }
    } else if (state.justEvaluated) resultDisplay.textContent = formatNumber(state.lastResult);
    $('#precision-hint').textContent = `up to ${state.settings.precision} decimal places`;
  }

  function updateMemory() {
    $('#memory-value').textContent = formatNumber(state.settings.memory);
    const hasMemory = state.settings.memory !== 0;
    $('#memory-indicator').textContent = hasMemory ? 'STORED' : 'EMPTY';
    $('#memory-indicator').classList.toggle('has-memory', hasMemory);
  }

  function updateAngleButtons() {
    $$('[data-angle]').forEach(button => button.classList.toggle('is-selected', button.dataset.angle === state.settings.angle));
  }

  function applySettings() {
    document.documentElement.dataset.theme = state.settings.theme;
    document.documentElement.dataset.buttonStyle = state.settings.buttonStyle;
    $('#theme-icon').textContent = state.settings.theme === 'dark' ? '☼' : '☾';
    $('#theme-toggle').setAttribute('aria-label', `Switch to ${state.settings.theme === 'dark' ? 'light' : 'dark'} theme`);
    $('#theme-setting').value = state.settings.theme;
    $('#button-style-setting').value = state.settings.buttonStyle;
    $('#precision-setting').value = String(state.settings.precision);
    $('#sound-setting').checked = state.settings.sound;
    updateAngleButtons();
    updateMemory();
    updateDisplay();
    persistSettings();
  }

  function setMode(mode) {
    if (!MODES[mode]) return;
    state.mode = mode;
    const meta = MODES[mode];
    modeTitle.textContent = meta.title;
    modeKicker.textContent = meta.kicker;
    modeDescription.textContent = meta.description;
    $('#display-label').textContent = meta.label;
    calculatorPanel.hidden = !['standard', 'scientific'].includes(mode);
    percentagePanel.hidden = mode !== 'percentage';
    historyPanel.hidden = mode !== 'history';
    $('#angle-switch-wrap').hidden = mode !== 'scientific';
    scientificKeys.hidden = mode !== 'scientific';
    $$('.mode-link').forEach(button => {
      const active = button.dataset.mode === mode;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-current', active ? 'page' : 'false');
    });
    if (mode === 'history') renderHistoryPage();
  }

  function createKey(label, action, value = '', className = '', title = '') {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `calculator-key ${className}`.trim();
    button.textContent = label;
    button.dataset.action = action;
    if (value) button.dataset.value = value;
    if (title) button.title = title;
    button.setAttribute('aria-label', title || label);
    return button;
  }

  function buildKeypads() {
    const keys = [
      ['AC', 'all-clear', '', 'key-utility'], ['C', 'clear-entry', '', 'key-utility'], ['⌫', 'backspace', '', 'key-utility', 'Delete last digit'], ['%', 'percent', '', 'key-operator'],
      ['7', 'digit', '7', ''], ['8', 'digit', '8', ''], ['9', 'digit', '9', ''], ['÷', 'operator', '/', 'key-operator'],
      ['4', 'digit', '4', ''], ['5', 'digit', '5', ''], ['6', 'digit', '6', ''], ['×', 'operator', '*', 'key-operator'],
      ['1', 'digit', '1', ''], ['2', 'digit', '2', ''], ['3', 'digit', '3', ''], ['−', 'operator', '-', 'key-operator'],
      ['±', 'sign', '', 'key-utility'], ['0', 'digit', '0', ''], ['.', 'decimal', '', ''], ['+', 'operator', '+', 'key-operator'],
      ['=', 'equals', '', 'key-equals']
    ];
    keypad.replaceChildren(...keys.map(([label, action, value, className, title]) => createKey(label, action, value, className, title)));
    const scientific = [
      ['(', 'left-paren', '(', ''], [')', 'right-paren', ')', ''], ['π', 'constant', 'pi', ''], ['e', 'constant', 'e', ''], ['xʸ', 'operator', '^', 'key-operator'],
      ['sin', 'function', 'sin', ''], ['cos', 'function', 'cos', ''], ['tan', 'function', 'tan', ''], ['√', 'function', 'sqrt', ''], ['x²', 'power', '2', ''],
      ['log', 'function', 'log', ''], ['ln', 'function', 'ln', ''], ['n!', 'factorial', '', ''], ['1/x', 'reciprocal', '', ''], ['x³', 'power', '3', '']
    ];
    scientificKeys.replaceChildren(...scientific.map(([label, action, value, className]) => createKey(label, action, value, className, label)));
  }

  function playSound() {
    if (!state.settings.sound) return;
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return;
      if (!state.audioContext) state.audioContext = new AudioContextClass();
      if (state.audioContext.state === 'suspended') state.audioContext.resume();
      const oscillator = state.audioContext.createOscillator();
      const gain = state.audioContext.createGain();
      oscillator.type = 'sine';
      oscillator.frequency.value = 690;
      gain.gain.setValueAtTime(.025, state.audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001, state.audioContext.currentTime + .035);
      oscillator.connect(gain);
      gain.connect(state.audioContext.destination);
      oscillator.start();
      oscillator.stop(state.audioContext.currentTime + .04);
    } catch { /* Sound is an optional enhancement. */ }
  }

  function showToast(message) {
    toast.textContent = message;
    toast.classList.add('is-visible');
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 2200);
  }

  function clearError() { state.error = ''; }

  function prepareForNewValue() {
    if (state.error) state.expression = '';
    if (state.justEvaluated) state.expression = '';
    state.justEvaluated = false;
    state.lastFormula = '';
    clearError();
  }

  function prepareForEdit() {
    if (state.error) state.expression = '';
    state.justEvaluated = false;
    state.lastFormula = '';
    clearError();
  }

  function expressionEndsWithValue() {
    return /(?:\d|\)|!|%|\bpi\b|\be\b)$/i.test(state.expression);
  }

  function appendDigit(digit) {
    prepareForNewValue();
    if (expressionEndsWithValue() && /(?:\)|!|%|\bpi\b|\be\b)$/i.test(state.expression)) state.expression += '*';
    state.expression += digit;
    updateDisplay();
  }

  function appendDecimal() {
    prepareForNewValue();
    const currentNumber = state.expression.match(/(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d*)?$/);
    if (currentNumber && currentNumber[0].includes('.')) return;
    if (expressionEndsWithValue() && /(?:\)|!|%|\bpi\b|\be\b)$/i.test(state.expression)) state.expression += '*';
    state.expression += currentNumber ? '.' : '0.';
    updateDisplay();
  }

  function appendOperator(operator) {
    if (state.error) { state.expression = ''; state.error = ''; }
    if (state.justEvaluated) { state.justEvaluated = false; state.lastFormula = ''; }
    if (!state.expression) {
      if (operator === '-') state.expression = '-';
      updateDisplay();
      return;
    }
    const last = state.expression[state.expression.length - 1];
    if (OPERATORS.has(last)) {
      if (operator === '-' && last !== '-') state.expression += operator;
      else if (state.expression.length === 1 && last === '-') return;
      else state.expression = state.expression.slice(0, -1) + operator;
    } else if (last === '(') {
      if (operator === '-') state.expression += operator;
    } else {
      state.expression += operator;
    }
    updateDisplay();
  }

  function appendFunction(name) {
    prepareForNewValue();
    if (expressionEndsWithValue()) state.expression += '*';
    state.expression += `${name}(`;
    updateDisplay();
  }

  function appendConstant(name) {
    prepareForNewValue();
    if (expressionEndsWithValue()) state.expression += '*';
    state.expression += name;
    updateDisplay();
  }

  function appendParenthesis(opening) {
    if (opening) {
      prepareForNewValue();
      if (expressionEndsWithValue()) state.expression += '*';
      state.expression += '(';
    } else {
      prepareForEdit();
      const opens = (state.expression.match(/\(/g) || []).length;
      const closes = (state.expression.match(/\)/g) || []).length;
      if (opens > closes && expressionEndsWithValue()) state.expression += ')';
    }
    updateDisplay();
  }

  function appendPostfix(symbol) {
    prepareForEdit();
    if (!expressionEndsWithValue()) return;
    if (state.expression.endsWith(symbol)) return;
    state.expression += symbol;
    updateDisplay();
  }

  function appendPower(power) {
    prepareForEdit();
    if (!expressionEndsWithValue()) return;
    state.expression += `^${power}`;
    updateDisplay();
  }

  function toggleSign() {
    prepareForEdit();
    if (!state.expression) { state.expression = '-'; updateDisplay(); return; }
    const match = state.expression.match(/(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/);
    if (match) {
      const start = match.index;
      const before = state.expression[start - 1];
      const beforeBefore = state.expression[start - 2];
      const isUnaryMinus = before === '-' && (start - 1 === 0 || OPERATORS.has(beforeBefore) || beforeBefore === '(');
      state.expression = isUnaryMinus
        ? state.expression.slice(0, start - 1) + state.expression.slice(start)
        : state.expression.slice(0, start) + '-' + state.expression.slice(start);
    } else if (expressionEndsWithValue()) {
      state.expression = `-(${state.expression})`;
    } else if (state.expression === '-') {
      state.expression = '';
    }
    updateDisplay();
  }

  function clearEntry() {
    state.error = '';
    if (state.justEvaluated) {
      state.expression = '';
      state.justEvaluated = false;
      state.lastFormula = '';
      updateDisplay();
      return;
    }
    const numericEntry = state.expression.match(/(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d*)?$/);
    if (numericEntry) {
      const start = numericEntry.index;
      const before = state.expression[start - 1];
      const beforeBefore = state.expression[start - 2];
      const signStart = before === '-' && (start - 1 === 0 || OPERATORS.has(beforeBefore) || beforeBefore === '(') ? start - 1 : start;
      state.expression = state.expression.slice(0, signStart);
    } else if (state.expression && OPERATORS.has(state.expression[state.expression.length - 1])) {
      state.expression = state.expression.slice(0, -1);
    } else {
      state.expression = '';
    }
    updateDisplay();
  }

  function backspace() {
    state.error = '';
    if (state.justEvaluated) {
      state.expression = cleanNumber(state.lastResult);
      state.justEvaluated = false;
      state.lastFormula = '';
      state.expression = state.expression.slice(0, -1);
    } else if (/(?:sin|cos|tan|log|ln|sqrt)\($/i.test(state.expression)) {
      state.expression = state.expression.replace(/(?:sin|cos|tan|log|ln|sqrt)\($/i, '');
    } else {
      state.expression = state.expression.slice(0, -1);
    }
    updateDisplay();
  }

  function allClear() {
    state.expression = '';
    state.error = '';
    state.justEvaluated = false;
    state.lastFormula = '';
    state.lastResult = 0;
    updateDisplay();
  }

  function calculate() {
    if (!state.expression) { state.error = 'Enter a calculation first.'; updateDisplay(); return; }
    try {
      const formula = state.expression;
      const result = evaluate(formula);
      state.lastResult = result;
      state.lastFormula = formula;
      state.expression = cleanNumber(result);
      state.justEvaluated = true;
      state.error = '';
      addHistory(formula, result);
      updateDisplay();
      renderRecent();
    } catch (error) {
      state.error = error instanceof Error ? error.message : 'This calculation could not be completed.';
      updateDisplay();
    }
  }

  function currentValue() {
    if (state.expression) return evaluate(state.expression);
    return state.lastResult;
  }

  function memoryAction(action) {
    playSound();
    if (action === 'mc') state.settings.memory = 0;
    else if (action === 'mr') {
      appendLiteral(cleanNumber(state.settings.memory));
      return;
    } else {
      let value;
      try { value = currentValue(); } catch (error) { showToast(error.message); return; }
      if (action === 'ms') state.settings.memory = value;
      if (action === 'mplus') state.settings.memory += value;
      if (action === 'mminus') state.settings.memory -= value;
    }
    persistSettings();
    updateMemory();
    showToast(action === 'mc' ? 'Memory cleared' : 'Memory updated');
  }

  function appendLiteral(value) {
    prepareForNewValue();
    if (expressionEndsWithValue()) state.expression += '*';
    state.expression += value;
    updateDisplay();
  }

  function addHistory(expression, result) {
    const entry = { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, expression, result: cleanNumber(result), time: Date.now() };
    state.history.unshift(entry);
    state.history = state.history.slice(0, 100);
    safeSave(HISTORY_KEY, state.history);
    renderHistoryPage();
  }

  function relativeTime(timestamp) {
    const elapsed = Math.max(0, Date.now() - timestamp);
    if (elapsed < 60000) return 'Just now';
    if (elapsed < 3600000) return `${Math.floor(elapsed / 60000)}m ago`;
    if (elapsed < 86400000) return `${Math.floor(elapsed / 3600000)}h ago`;
    return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(new Date(timestamp));
  }

  function createHistoryItem(entry, showDelete = true) {
    const item = document.createElement('article');
    item.className = 'history-item';
    const main = document.createElement('button');
    main.type = 'button';
    main.className = 'history-main';
    main.dataset.historyAction = 'reuse';
    main.dataset.id = entry.id;
    main.title = 'Reuse this result';
    const formula = document.createElement('span');
    formula.className = 'history-expression';
    formula.textContent = displayExpression(entry.expression);
    const result = document.createElement('span');
    result.className = 'history-result';
    result.textContent = formatNumber(Number(entry.result));
    main.append(formula, result);
    const side = document.createElement('div');
    side.className = 'history-side';
    const time = document.createElement('span');
    time.className = 'history-time';
    time.textContent = relativeTime(entry.time);
    side.append(time);
    if (showDelete) {
      const del = document.createElement('button');
      del.type = 'button';
      del.className = 'history-delete';
      del.dataset.historyAction = 'delete';
      del.dataset.id = entry.id;
      del.setAttribute('aria-label', 'Delete calculation');
      del.title = 'Delete calculation';
      del.textContent = '×';
      side.append(del);
    }
    item.append(main, side);
    return item;
  }

  function emptyState(message) {
    const element = document.createElement('div');
    element.className = 'empty-state';
    const inner = document.createElement('div');
    const icon = document.createElement('span');
    icon.className = 'empty-icon';
    icon.textContent = '∑';
    const text = document.createElement('span');
    text.textContent = message;
    inner.append(icon, text);
    element.append(inner);
    return element;
  }

  function renderRecent() {
    const list = $('#recent-list');
    list.replaceChildren();
    if (!state.history.length) list.append(emptyState('Your calculations will show up here.'));
    else state.history.slice(0, 4).forEach(entry => list.append(createHistoryItem(entry, false)));
    renderHistoryPage();
  }

  function renderHistoryPage() {
    const list = $('#history-list');
    if (!list) return;
    list.replaceChildren();
    if (!state.history.length) list.append(emptyState('Nothing here yet. Complete a calculation and it will be saved here.'));
    else state.history.forEach(entry => list.append(createHistoryItem(entry, true)));
  }

  function clearHistory() {
    state.history = [];
    safeSave(HISTORY_KEY, state.history);
    renderRecent();
    showToast('Calculation history cleared');
  }

  function handleHistoryAction(event) {
    const button = event.target.closest('[data-history-action]');
    if (!button) return;
    const entry = state.history.find(item => item.id === button.dataset.id);
    if (!entry) return;
    if (button.dataset.historyAction === 'delete') {
      state.history = state.history.filter(item => item.id !== entry.id);
      safeSave(HISTORY_KEY, state.history);
      renderRecent();
      return;
    }
    state.expression = entry.result;
    state.lastResult = Number(entry.result);
    state.justEvaluated = true;
    state.lastFormula = entry.expression;
    state.error = '';
    setMode('standard');
    updateDisplay();
    showToast('Result loaded into the calculator');
  }

  function calculatePercentage(saveCalculation = true) {
    const rateText = $('#percent-rate').value.trim();
    const baseText = $('#percent-base').value.trim();
    const rate = Number(rateText);
    const base = Number(baseText);
    if (!rateText || !baseText || !Number.isFinite(rate) || !Number.isFinite(base)) {
      showToast('Enter a valid percentage and amount.');
      return;
    }
    const percentValue = base * rate / 100;
    const value = state.percentOperation === 'increase' ? base + percentValue
      : state.percentOperation === 'decrease' ? base - percentValue : percentValue;
    if (!Number.isFinite(value)) { showToast('That result is outside the calculator’s range.'); return; }
    state.percentResult = value;
    $('#percent-result').textContent = formatNumber(value);
    const operationText = state.percentOperation === 'increase' ? `increase ${formatNumber(base)} by ${formatNumber(rate)}%`
      : state.percentOperation === 'decrease' ? `decrease ${formatNumber(base)} by ${formatNumber(rate)}%`
        : `${formatNumber(rate)}% of ${formatNumber(base)}`;
    $('#percent-summary').textContent = operationText;
    const historyFormula = `${operationText}`;
    if (saveCalculation) {
      addHistory(historyFormula, value);
      renderRecent();
      showToast('Percentage calculated');
    }
  }

  function changePercentOperation(operation) {
    state.percentOperation = operation;
    $$('[data-percent-operation]').forEach(button => button.classList.toggle('is-selected', button.dataset.percentOperation === operation));
    const labels = {
      of: { rate: 'What is', connector: 'of' },
      increase: { rate: 'Increase this amount by', connector: 'by' },
      decrease: { rate: 'Decrease this amount by', connector: 'by' }
    }[operation];
    $('#percent-rate-label').textContent = labels.rate;
    $('#percent-connector').textContent = labels.connector;
    calculatePercentage(false);
  }

  function copyResult() {
    let value;
    try { value = state.expression ? currentValue() : state.lastResult; }
    catch (error) { showToast(error.message); return; }
    const text = formatNumber(value);
    const fallbackCopy = () => {
      const input = document.createElement('textarea');
      input.value = text;
      input.style.position = 'fixed';
      input.style.opacity = '0';
      document.body.append(input);
      input.select();
      let success = false;
      try { success = document.execCommand('copy'); } catch { success = false; }
      input.remove();
      showToast(success ? 'Result copied to clipboard' : 'Could not copy the result');
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(() => showToast('Result copied to clipboard')).catch(fallbackCopy);
    } else fallbackCopy();
  }

  function handleKeyAction(button) {
    playSound();
    const { action, value } = button.dataset;
    switch (action) {
      case 'digit': appendDigit(value); break;
      case 'decimal': appendDecimal(); break;
      case 'operator': appendOperator(value); break;
      case 'all-clear': allClear(); break;
      case 'clear-entry': clearEntry(); break;
      case 'backspace': backspace(); break;
      case 'equals': calculate(); break;
      case 'percent': appendPostfix('%'); break;
      case 'sign': toggleSign(); break;
      case 'function': appendFunction(value); break;
      case 'constant': appendConstant(value); break;
      case 'left-paren': appendParenthesis(true); break;
      case 'right-paren': appendParenthesis(false); break;
      case 'factorial': appendPostfix('!'); break;
      case 'power': appendPower(value); break;
      case 'reciprocal':
        if (state.expression && expressionEndsWithValue()) {
          state.expression = `1/(${state.expression})`;
          state.justEvaluated = false;
          state.lastFormula = '';
          state.error = '';
          updateDisplay();
        }
        break;
      default: break;
    }
  }

  function handleKeyboard(event) {
    if (event.altKey && /^[1-4]$/.test(event.key)) {
      event.preventDefault();
      setMode(['standard', 'scientific', 'percentage', 'history'][Number(event.key) - 1]);
      return;
    }
    if (event.ctrlKey || event.metaKey) return;
    if (event.key === 'Enter' && event.target.closest('button')) return;
    if (event.target.matches('input, select, textarea, [contenteditable="true"]') || settingsDialog.open) return;
    if (/^\d$/.test(event.key) || ['.', '+', '-', '*', '/', '^', 'x', 'X', '=', 'Enter', 'Backspace', 'Delete', 'Escape', '%', '(', ')', '!', 'c', 'C'].includes(event.key)) playSound();
    if (/^\d$/.test(event.key)) { event.preventDefault(); appendDigit(event.key); }
    else if (event.key === '.') { event.preventDefault(); appendDecimal(); }
    else if (['+', '-', '*', '/', '^'].includes(event.key)) { event.preventDefault(); appendOperator(event.key); }
    else if (event.key === 'x' || event.key === 'X') { event.preventDefault(); appendOperator('*'); }
    else if (event.key === 'Enter' || event.key === '=') { event.preventDefault(); calculate(); }
    else if (event.key === 'Backspace') { event.preventDefault(); backspace(); }
    else if (event.key === 'Delete') { event.preventDefault(); clearEntry(); }
    else if (event.key.toLowerCase() === 'c') { event.preventDefault(); clearEntry(); }
    else if (event.key === 'Escape') { event.preventDefault(); allClear(); }
    else if (event.key === '%') { event.preventDefault(); appendPostfix('%'); }
    else if (event.key === '(') { event.preventDefault(); appendParenthesis(true); }
    else if (event.key === ')') { event.preventDefault(); appendParenthesis(false); }
    else if (event.key === '!') { event.preventDefault(); appendPostfix('!'); }
  }

  keypad.addEventListener('click', event => {
    const button = event.target.closest('[data-action]');
    if (button) handleKeyAction(button);
  });
  scientificKeys.addEventListener('click', event => {
    const button = event.target.closest('[data-action]');
    if (button) handleKeyAction(button);
  });
  $$('.mode-link').forEach(button => button.addEventListener('click', () => setMode(button.dataset.mode)));
  $$('[data-mode-link]').forEach(button => button.addEventListener('click', event => { event.preventDefault(); setMode(button.dataset.modeLink); }));
  $$('[data-memory]').forEach(button => button.addEventListener('click', () => memoryAction(button.dataset.memory)));
  $$('[data-angle]').forEach(button => button.addEventListener('click', () => {
    state.settings.angle = button.dataset.angle;
    persistSettings();
    updateAngleButtons();
    updateDisplay();
    showToast(`Angle unit set to ${state.settings.angle.toUpperCase()}`);
  }));
  $$('[data-percent-operation]').forEach(button => button.addEventListener('click', () => changePercentOperation(button.dataset.percentOperation)));
  $('#calculate-percent').addEventListener('click', calculatePercentage);
  $('#use-percent-result').addEventListener('click', () => {
    state.expression = cleanNumber(state.percentResult);
    state.lastResult = state.percentResult;
    state.justEvaluated = true;
    state.lastFormula = 'Percentage result';
    state.error = '';
    setMode('standard');
    updateDisplay();
  });
  $('#copy-result').addEventListener('click', copyResult);
  $('#view-history').addEventListener('click', () => setMode('history'));
  $('#view-all-history').addEventListener('click', () => setMode('history'));
  $('#clear-history').addEventListener('click', clearHistory);
  $('#settings-clear-history').addEventListener('click', clearHistory);
  $('#history-list').addEventListener('click', handleHistoryAction);
  $('#recent-list').addEventListener('click', handleHistoryAction);
  $('#theme-toggle').addEventListener('click', () => {
    state.settings.theme = state.settings.theme === 'dark' ? 'light' : 'dark';
    applySettings();
  });
  $('#open-settings').addEventListener('click', () => {
    applySettings();
    settingsDialog.showModal();
  });
  $('#theme-setting').addEventListener('change', event => { state.settings.theme = event.target.value; applySettings(); });
  $('#button-style-setting').addEventListener('change', event => { state.settings.buttonStyle = event.target.value; applySettings(); });
  $('#precision-setting').addEventListener('change', event => { state.settings.precision = Number(event.target.value); applySettings(); });
  $('#sound-setting').addEventListener('change', event => { state.settings.sound = event.target.checked; persistSettings(); });
  $('#settings-form').addEventListener('submit', () => persistSettings());
  document.addEventListener('keydown', handleKeyboard);

  buildKeypads();
  applySettings();
  renderRecent();
  setMode('standard');
  $('#percent-result').textContent = formatNumber(state.percentResult);
  $('#percent-summary').textContent = '15% of 240';
})();
